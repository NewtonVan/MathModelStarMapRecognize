# 第16届研究生数学建模竞赛B题 星图识别
## 题目
[数学建模网](https://www.shumo.com/home/html/4210.html)
## 运行
1. 依据CMakeList.txt安装和构建
2. 在data目录运行
## 结果
### 第一题第一问
星星选取：

![计算结果](result/1.png)
计算结果：

![计算结果](result/2.png)
### 第二题 星图8识别结果
识别结果：

![识别结果](result/recognition.png)
识别报告：

![识别结果](result/recognition_report.png)
